import { useState } from 'react'
import { FileSpreadsheet, FileText, Download, Loader2, Check, X } from 'lucide-react'
import { useCurrency } from '../currency'
import { useTranslation } from '../i18n'

// ============================================
// EXPORT DATA - PDF & EXCEL
// ============================================

// Fonction pour mettre en majuscule la première lettre
const capitalize = (str) => {
  if (!str) return ''
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase()
}

export default function ExportData({ transactions, isDark, onClose }) {
  const { formatMoney, currentCurrency } = useCurrency()
  const { language } = useTranslation()
  const [exporting, setExporting] = useState(null)
  const [success, setSuccess] = useState(null)

  const labels = {
    fr: {
      title: 'Exporter mes données',
      subtitle: 'Choisissez le format d\'export',
      excel: 'Excel (.xlsx)',
      excelDesc: 'Tableur avec toutes vos transactions',
      pdf: 'PDF',
      pdfDesc: 'Rapport mensuel formaté',
      exporting: 'Export en cours...',
      success: 'Export réussi !',
      noData: 'Aucune transaction à exporter',
      cancel: 'Fermer',
      columns: {
        date: 'Date',
        type: 'Type',
        category: 'Catégorie',
        description: 'Description',
        amount: 'Montant',
        payment: 'Paiement',
        income: 'Revenu',
        expense: 'Dépense',
      }
    },
    en: {
      title: 'Export my data',
      subtitle: 'Choose export format',
      excel: 'Excel (.xlsx)',
      excelDesc: 'Spreadsheet with all your transactions',
      pdf: 'PDF',
      pdfDesc: 'Formatted monthly report',
      exporting: 'Exporting...',
      success: 'Export successful!',
      noData: 'No transactions to export',
      cancel: 'Close',
      columns: {
        date: 'Date',
        type: 'Type',
        category: 'Category',
        description: 'Description',
        amount: 'Amount',
        payment: 'Payment',
        income: 'Income',
        expense: 'Expense',
      }
    }
  }

  const t = labels[language] || labels.fr

  // ========== EXPORT EXCEL (CSV) ==========
  const exportExcel = async () => {
    if (transactions.length === 0) {
      alert(t.noData)
      return
    }

    setExporting('excel')
    setSuccess(null)

    try {
      // Créer le contenu CSV
      const headers = [
        t.columns.date,
        t.columns.type,
        t.columns.category,
        t.columns.description,
        t.columns.amount,
        t.columns.payment
      ]

      const rows = transactions.map(tr => [
        tr.date,
        tr.type === 'income' ? t.columns.income : t.columns.expense,
        capitalize(tr.category),
        tr.description || '',
        tr.amount,
        tr.payment_method || 'cash'
      ])

      // Ajouter BOM pour Excel (UTF-8)
      const BOM = '\uFEFF'
      const csvContent = BOM + [
        headers.join(';'),
        ...rows.map(row => row.map(cell => `"${cell}"`).join(';'))
      ].join('\n')

      // Créer et télécharger le fichier
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `seka-money-export-${new Date().toISOString().split('T')[0]}.csv`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)

      setSuccess('excel')
      setTimeout(() => setSuccess(null), 2000)
    } catch (error) {
      console.error('Erreur export Excel:', error)
      alert('Erreur lors de l\'export')
    } finally {
      setExporting(null)
    }
  }

  // ========== EXPORT PDF ==========
  const exportPDF = async () => {
    if (transactions.length === 0) {
      alert(t.noData)
      return
    }

    setExporting('pdf')
    setSuccess(null)

    try {
      // Calculer les statistiques
      const totalIncome = transactions
        .filter(t => t.type === 'income')
        .reduce((s, t) => s + t.amount, 0)
      const totalExpense = transactions
        .filter(t => t.type === 'expense')
        .reduce((s, t) => s + t.amount, 0)
      const balance = totalIncome - totalExpense

      // Grouper par catégorie
      const byCategory = {}
      transactions.filter(t => t.type === 'expense').forEach(tr => {
        const catName = capitalize(tr.category)
        if (!byCategory[catName]) {
          byCategory[catName] = 0
        }
        byCategory[catName] += tr.amount
      })

      // Logo SEKA en SVG (basé sur le design bleu)
      const logoSVG = `
        <svg width="180" height="50" viewBox="0 0 180 50" xmlns="http://www.w3.org/2000/svg">
          <!-- Cercle avec flèches -->
          <circle cx="25" cy="25" r="20" fill="none" stroke="#0077B6" stroke-width="3"/>
          <path d="M25 8 L25 5 L30 10 L25 8" fill="#00B4D8"/>
          <path d="M25 42 L25 45 L20 40 L25 42" fill="#0077B6"/>
          <!-- S au centre -->
          <text x="25" y="32" font-family="Arial, sans-serif" font-size="20" font-weight="bold" fill="#0077B6" text-anchor="middle">S</text>
          <!-- SEKA -->
          <text x="55" y="28" font-family="Arial, sans-serif" font-size="22" font-weight="bold" fill="#0077B6">SEKA</text>
          <!-- Money -->
          <text x="55" y="45" font-family="Arial, sans-serif" font-size="18" font-weight="500" fill="#00B4D8">Money</text>
        </svg>
      `

      // Créer le HTML du rapport
      const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>SEKA Money - ${language === 'fr' ? 'Rapport' : 'Report'}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      padding: 40px;
      color: #1a1a1a;
      background: #fff;
    }
    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 40px;
      padding-bottom: 20px;
      border-bottom: 3px solid #0077B6;
    }
    .logo {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .logo-icon {
      width: 50px;
      height: 50px;
      background: linear-gradient(135deg, #0077B6, #00B4D8);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 28px;
      font-weight: bold;
      position: relative;
    }
    .logo-icon::before {
      content: '';
      position: absolute;
      inset: -3px;
      border: 2px solid #00B4D8;
      border-radius: 14px;
      opacity: 0.3;
    }
    .logo-text {
      display: flex;
      flex-direction: column;
    }
    .logo-text .brand {
      font-size: 24px;
      font-weight: 800;
      color: #0077B6;
      letter-spacing: -0.5px;
    }
    .logo-text .sub {
      font-size: 14px;
      color: #00B4D8;
      font-weight: 500;
    }
    .header-info {
      text-align: right;
    }
    .header-info h2 {
      font-size: 16px;
      color: #333;
      margin-bottom: 4px;
    }
    .header-info p {
      color: #666;
      font-size: 13px;
    }
    .summary {
      display: flex;
      gap: 20px;
      margin-bottom: 30px;
    }
    .summary-card {
      flex: 1;
      padding: 20px;
      border-radius: 12px;
      text-align: center;
      border: 1px solid #eee;
    }
    .summary-card.income { 
      background: linear-gradient(135deg, #E8F5E9, #C8E6C9);
      border-color: #A5D6A7;
    }
    .summary-card.expense { 
      background: linear-gradient(135deg, #FFEBEE, #FFCDD2);
      border-color: #EF9A9A;
    }
    .summary-card.balance { 
      background: linear-gradient(135deg, #E3F2FD, #BBDEFB);
      border-color: #90CAF9;
    }
    .summary-card h3 {
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: #666;
      margin-bottom: 8px;
    }
    .summary-card .amount {
      font-size: 22px;
      font-weight: bold;
    }
    .summary-card.income .amount { color: #2E7D32; }
    .summary-card.expense .amount { color: #C62828; }
    .summary-card.balance .amount { color: #1565C0; }
    .section {
      margin-bottom: 30px;
    }
    .section h2 {
      font-size: 14px;
      font-weight: 600;
      margin-bottom: 15px;
      padding-bottom: 8px;
      border-bottom: 2px solid #0077B6;
      color: #0077B6;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
    }
    th, td {
      padding: 12px 10px;
      text-align: left;
      border-bottom: 1px solid #eee;
    }
    th {
      background: linear-gradient(135deg, #0077B6, #0096C7);
      color: white;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 10px;
      letter-spacing: 0.5px;
    }
    th:first-child { border-radius: 8px 0 0 0; }
    th:last-child { border-radius: 0 8px 0 0; }
    tr:nth-child(even) { background: #f9f9f9; }
    tr:hover { background: #f0f7ff; }
    .amount-income { color: #2E7D32; font-weight: 600; }
    .amount-expense { color: #C62828; font-weight: 600; }
    .footer {
      margin-top: 40px;
      text-align: center;
      padding-top: 20px;
      border-top: 1px solid #eee;
    }
    .footer p {
      color: #999;
      font-size: 11px;
    }
    .footer .brand {
      color: #0077B6;
      font-weight: 600;
    }
    .categories {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px;
    }
    .category-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 15px;
      background: #f8f9fa;
      border-radius: 8px;
      border-left: 4px solid #0077B6;
    }
    .category-item span:first-child {
      font-weight: 500;
      color: #333;
    }
    @media print {
      body { padding: 20px; }
      .summary { flex-wrap: wrap; }
      .summary-card { min-width: 150px; }
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="logo">
      <div class="logo-icon">S</div>
      <div class="logo-text">
        <span class="brand">SEKA Money</span>
        <span class="sub">Gérez votre argent simplement</span>
      </div>
    </div>
    <div class="header-info">
      <h2>${language === 'fr' ? 'Rapport Financier' : 'Financial Report'}</h2>
      <p>${new Date().toLocaleDateString(language === 'fr' ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
    </div>
  </div>

  <div class="summary">
    <div class="summary-card income">
      <h3>${language === 'fr' ? 'Revenus' : 'Income'}</h3>
      <div class="amount">+${formatMoney(totalIncome)}</div>
    </div>
    <div class="summary-card expense">
      <h3>${language === 'fr' ? 'Dépenses' : 'Expenses'}</h3>
      <div class="amount">-${formatMoney(totalExpense)}</div>
    </div>
    <div class="summary-card balance">
      <h3>${language === 'fr' ? 'Solde' : 'Balance'}</h3>
      <div class="amount">${balance >= 0 ? '+' : ''}${formatMoney(balance)}</div>
    </div>
  </div>

  <div class="section">
    <h2>${language === 'fr' ? 'Dépenses par catégorie' : 'Expenses by category'}</h2>
    <div class="categories">
      ${Object.entries(byCategory)
        .sort((a, b) => b[1] - a[1])
        .map(([cat, amount]) => `
          <div class="category-item">
            <span>${cat}</span>
            <span class="amount-expense">-${formatMoney(amount)}</span>
          </div>
        `).join('')}
    </div>
  </div>

  <div class="section">
    <h2>${language === 'fr' ? 'Détail des transactions' : 'Transaction details'} (${transactions.length})</h2>
    <table>
      <thead>
        <tr>
          <th>${t.columns.date}</th>
          <th>${t.columns.category}</th>
          <th>${t.columns.description}</th>
          <th style="text-align: right">${t.columns.amount}</th>
        </tr>
      </thead>
      <tbody>
        ${transactions.slice(0, 50).map(tr => `
          <tr>
            <td>${new Date(tr.date).toLocaleDateString(language === 'fr' ? 'fr-FR' : 'en-US')}</td>
            <td>${capitalize(tr.category)}</td>
            <td>${tr.description || '-'}</td>
            <td style="text-align: right" class="${tr.type === 'income' ? 'amount-income' : 'amount-expense'}">
              ${tr.type === 'income' ? '+' : '-'}${formatMoney(tr.amount)}
            </td>
          </tr>
        `).join('')}
        ${transactions.length > 50 ? `
          <tr>
            <td colspan="4" style="text-align: center; color: #999; font-style: italic;">
              ... ${language === 'fr' ? 'et' : 'and'} ${transactions.length - 50} ${language === 'fr' ? 'autres transactions' : 'more transactions'}
            </td>
          </tr>
        ` : ''}
      </tbody>
    </table>
  </div>

  <div class="footer">
    <p>${language === 'fr' ? 'Généré par' : 'Generated by'} <span class="brand">SEKA Money</span></p>
    <p style="margin-top: 5px;">${new Date().toLocaleString(language === 'fr' ? 'fr-FR' : 'en-US')}</p>
  </div>
</body>
</html>
      `

      // Ouvrir dans une nouvelle fenêtre pour impression
      const printWindow = window.open('', '_blank')
      printWindow.document.write(html)
      printWindow.document.close()
      
      // Attendre le chargement puis imprimer
      printWindow.onload = () => {
        printWindow.print()
      }

      setSuccess('pdf')
      setTimeout(() => setSuccess(null), 2000)
    } catch (error) {
      console.error('Erreur export PDF:', error)
      alert('Erreur lors de l\'export')
    } finally {
      setExporting(null)
    }
  }

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div 
        className={`w-full max-w-sm rounded-2xl overflow-hidden ${isDark ? 'bg-seka-card' : 'bg-white'}`}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className={`px-5 py-4 border-b flex items-center justify-between ${isDark ? 'border-seka-border' : 'border-gray-200'}`}>
          <div>
            <h3 className={`font-semibold text-lg ${isDark ? 'text-seka-text' : 'text-gray-900'}`}>
              {t.title}
            </h3>
            <p className={`text-xs ${isDark ? 'text-seka-text-muted' : 'text-gray-500'}`}>
              {t.subtitle}
            </p>
          </div>
          <button onClick={onClose} className={`p-2 rounded-lg ${isDark ? 'hover:bg-seka-darker' : 'hover:bg-gray-100'}`}>
            <X className={`w-5 h-5 ${isDark ? 'text-seka-text-muted' : 'text-gray-400'}`} />
          </button>
        </div>

        {/* Options */}
        <div className="p-4 space-y-3">
          {/* Excel */}
          <button
            onClick={exportExcel}
            disabled={exporting !== null}
            className={`w-full p-4 rounded-xl flex items-center gap-4 transition-all ${
              success === 'excel'
                ? 'bg-seka-green/20 border-2 border-seka-green'
                : isDark 
                  ? 'bg-seka-darker hover:bg-seka-darker/70 border border-seka-border' 
                  : 'bg-gray-50 hover:bg-gray-100 border border-gray-200'
            }`}
          >
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
              success === 'excel' ? 'bg-seka-green' : 'bg-green-500/20'
            }`}>
              {exporting === 'excel' ? (
                <Loader2 className="w-6 h-6 text-green-500 animate-spin" />
              ) : success === 'excel' ? (
                <Check className="w-6 h-6 text-seka-darker" />
              ) : (
                <FileSpreadsheet className="w-6 h-6 text-green-500" />
              )}
            </div>
            <div className="flex-1 text-left">
              <p className={`font-medium ${isDark ? 'text-seka-text' : 'text-gray-900'}`}>
                {t.excel}
              </p>
              <p className={`text-xs ${isDark ? 'text-seka-text-muted' : 'text-gray-500'}`}>
                {exporting === 'excel' ? t.exporting : success === 'excel' ? t.success : t.excelDesc}
              </p>
            </div>
            <Download className={`w-5 h-5 ${isDark ? 'text-seka-text-muted' : 'text-gray-400'}`} />
          </button>

          {/* PDF */}
          <button
            onClick={exportPDF}
            disabled={exporting !== null}
            className={`w-full p-4 rounded-xl flex items-center gap-4 transition-all ${
              success === 'pdf'
                ? 'bg-seka-green/20 border-2 border-seka-green'
                : isDark 
                  ? 'bg-seka-darker hover:bg-seka-darker/70 border border-seka-border' 
                  : 'bg-gray-50 hover:bg-gray-100 border border-gray-200'
            }`}
          >
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
              success === 'pdf' ? 'bg-seka-green' : 'bg-red-500/20'
            }`}>
              {exporting === 'pdf' ? (
                <Loader2 className="w-6 h-6 text-red-500 animate-spin" />
              ) : success === 'pdf' ? (
                <Check className="w-6 h-6 text-seka-darker" />
              ) : (
                <FileText className="w-6 h-6 text-red-500" />
              )}
            </div>
            <div className="flex-1 text-left">
              <p className={`font-medium ${isDark ? 'text-seka-text' : 'text-gray-900'}`}>
                {t.pdf}
              </p>
              <p className={`text-xs ${isDark ? 'text-seka-text-muted' : 'text-gray-500'}`}>
                {exporting === 'pdf' ? t.exporting : success === 'pdf' ? t.success : t.pdfDesc}
              </p>
            </div>
            <Download className={`w-5 h-5 ${isDark ? 'text-seka-text-muted' : 'text-gray-400'}`} />
          </button>
        </div>

        {/* Info */}
        <div className={`px-4 pb-4`}>
          <p className={`text-xs text-center ${isDark ? 'text-seka-text-muted' : 'text-gray-400'}`}>
            {transactions.length} transactions • {currentCurrency.labelShort}
          </p>
        </div>
      </div>
    </div>
  )
}
