import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronRight, Sparkles, Wallet, Target, Users, Shield, Check } from 'lucide-react'

const SLIDES = [
  {
    icon: Sparkles,
    title: 'Bienvenue sur SEKA Money',
    subtitle: 'Votre assistant financier personnel, conçu pour l\'Afrique',
    color: 'from-amber-500 to-orange-500',
    bgColor: 'bg-amber-500'
  },
  {
    icon: Wallet,
    title: 'Suivez chaque franc',
    subtitle: 'Enregistrez vos revenus et dépenses en quelques secondes. Zémidjan, Tontine, Mobile Money... tout est prévu.',
    color: 'from-emerald-500 to-green-600',
    bgColor: 'bg-emerald-500'
  },
  {
    icon: Target,
    title: 'Atteignez vos objectifs',
    subtitle: 'iPhone, voyage, voiture... Définissez vos rêves et économisez petit à petit.',
    color: 'from-violet-500 to-purple-600',
    bgColor: 'bg-violet-500'
  },
  {
    icon: Users,
    title: 'Gérez vos prêts',
    subtitle: 'Ne perdez plus la trace de qui vous doit de l\'argent. Recevez des rappels automatiques.',
    color: 'from-sky-500 to-blue-600',
    bgColor: 'bg-sky-500'
  },
  {
    icon: Shield,
    title: 'Vos données protégées',
    subtitle: 'Chiffrement de bout en bout. Vos finances restent privées.',
    color: 'from-emerald-500 to-teal-600',
    bgColor: 'bg-emerald-500'
  }
]

export default function Onboarding() {
  const navigate = useNavigate()
  const [currentSlide, setCurrentSlide] = useState(0)
  const isLast = currentSlide === SLIDES.length - 1
  const slide = SLIDES[currentSlide]
  const Icon = slide.icon

  const handleNext = () => {
    if (isLast) {
      localStorage.setItem('seka_onboarding_completed', 'true')
      navigate('/login')
    } else {
      setCurrentSlide(prev => prev + 1)
    }
  }

  const handleSkip = () => {
    localStorage.setItem('seka_onboarding_completed', 'true')
    navigate('/login')
  }

  const handleLogin = () => {
    localStorage.setItem('seka_onboarding_completed', 'true')
    navigate('/login')
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-900 to-black flex flex-col">
      {/* Skip button */}
      {!isLast && (
        <div className="absolute top-6 right-6 z-10">
          <button
            onClick={handleSkip}
            className="text-gray-400 hover:text-white text-sm font-medium px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm transition-all"
          >
            Passer
          </button>
        </div>
      )}

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 py-12">
        {/* Icon avec glow effect */}
        <div className="relative mb-12">
          <div className={`absolute inset-0 blur-3xl opacity-40 bg-gradient-to-r ${slide.color} rounded-full scale-150`} />
          <div className={`relative w-32 h-32 rounded-3xl bg-gradient-to-br ${slide.color} flex items-center justify-center shadow-2xl`}>
            <Icon className="w-16 h-16 text-white" strokeWidth={1.5} />
          </div>
        </div>

        {/* Text */}
        <div className="text-center max-w-sm">
          <h1 className="text-3xl font-bold text-white mb-4 leading-tight">
            {slide.title}
          </h1>
          <p className="text-gray-400 text-lg leading-relaxed">
            {slide.subtitle}
          </p>
        </div>
      </div>

      {/* Bottom section */}
      <div className="px-8 pb-12 space-y-6">
        {/* Dots */}
        <div className="flex items-center justify-center gap-2">
          {SLIDES.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentSlide(i)}
              className={`h-2 rounded-full transition-all duration-300 ${
                i === currentSlide 
                  ? `w-8 bg-gradient-to-r ${slide.color}` 
                  : 'w-2 bg-gray-600 hover:bg-gray-500'
              }`}
            />
          ))}
        </div>

        {/* Buttons */}
        {isLast ? (
          <div className="space-y-3">
            <button
              onClick={handleNext}
              className={`w-full py-4 rounded-2xl bg-gradient-to-r ${slide.color} text-white font-semibold text-lg flex items-center justify-center gap-2 shadow-lg`}
            >
              <Check className="w-5 h-5" />
              Créer un compte
            </button>
            <button
              onClick={handleLogin}
              className="w-full py-4 rounded-2xl bg-white/10 backdrop-blur-sm text-white font-medium border border-white/20"
            >
              J'ai déjà un compte
            </button>
          </div>
        ) : (
          <button
            onClick={handleNext}
            className={`w-full py-4 rounded-2xl bg-gradient-to-r ${slide.color} text-white font-semibold text-lg flex items-center justify-center gap-2 shadow-lg`}
          >
            Suivant
            <ChevronRight className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  )
}
